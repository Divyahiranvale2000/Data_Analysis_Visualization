# How to read feather data
import feather
import sqlite3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pyarrow
import warnings
from warnings import filterwarnings
# Read data from dataset
# Clean data
# df=pd.DataFrame()
#
# df.to_feather(r"C:\Users\902568\PycharmProjects\DataTransformation\Sales_Data_Analysis\4- Sales Data Analysis-20240610T161622Z-001\4- Sales Data Analysis/Sales_data.ftr")
# df=pd.read_feather(r"C:\Users\902568\PycharmProjects\DataTransformation\Sales_Data_Analysis\4- Sales Data Analysis-20240610T161622Z-001\4- Sales Data Analysis/Sales_data.ftr")
# df
df=pd.read_feather(r"C:\Users\902568\PycharmProjects\DataTransformation\Sales_Data_Analysis\4- Sales Data Analysis-20240610T161622Z-001\4- Sales Data Analysis/Sales_data.ftr")
print(df.head())
print(df.columns)
# Mark the missing values
# basic data clean
print(df.isnull().sum()) # 545 rows are there missing values are there
# delete missing avlues
df.dropna(how='all')
print(df.isnull().sum())
# returen duplicate data
print(df[df.duplicated()])
# delete duplicate data
df.drop_duplicates

# result as 0 bcz all duplicated rows deleted

# Requirement 2
# analysing on monthy sale
# which is best month for sale?

# month -->exctract from order date
# sale=qualtity * price

print(df['Order Date'][0])
print(df['Order Date'][0].split('/')[0])


df['Month']=df['Order Date'].str.split('/').str[0]

print(df.head())
# df['Month'].astype(int)
print(df.dtypes)
print("",df['Month'].unique())
filter1= df['Month']=='Order Date'
print(df[~filter1])
df=df[~filter1]
df=df.dropna(subset=['Month'])

df['Month']=df['Month'].astype(int)
print(df.head())
filterwarnings('ignore')
print(df.dtypes)
df['Quantity Ordered']=df['Quantity Ordered'].astype(int)
print("",df['Price Each'].unique())
df['Price Each']=df['Price Each'].astype(float)
print(df.dtypes)
df['sales']=df['Quantity Ordered'] * df['Price Each']
print("groupby",df.groupby(['Month'])['sales'].sum())
df.groupby(['Month'])['sales'].sum().plot(kind='bar')
# plt.show()

# Requirement 3
# Analyzing which city has Maximax Order!

# Which city has max order?
# print(df['Purchase Address'].str.split(',').str[1])
df['city']=df['Purchase Address'].str.split(',').str.get(1)
print(df['city'])
value_counts=df['city'].value_counts()
print(value_counts)
df['city'].value_counts().plot(kind='pie')
# plt.show()

# Requirement 3
# WHat product is sold max & why?
# Product sold most==Good Ratings for product & Low prices

print(df.columns)
print("groupby",df.groupby(['Product']).agg({'Quantity Ordered':'sum','Price Each':'mean'}))
count_df=df.groupby(['Product']).agg({'Quantity Ordered':'sum','Price Each':'mean'})
count_df=count_df.reset_index()
print("count_df",count_df)
fig, ax1=plt.subplots()
ax2=ax1.twinx()

print(count_df['Product'].values)
print("started plot")
ax1.bar(count_df['Product'],count_df['Quantity Ordered'],color='g')
ax2.plot(count_df['Product'],count_df['Price Each'])
ax1.set_xticklabels(count_df['Product'].values,rotation='vertical',fontsize=12)
ax1.set_ylabel('Order Count')
ax2.set_ylabel('Average price of product')
plt.show()

# Requirement 4
# Understdning the trade of most sold product !
# Pivot table need to make
# find most sold product?
print(df['Product'].value_counts())
# indexing for to ftech top 5
print(df['Product'].value_counts()[0:5])
print(df['Product'].value_counts()[0:5].index)
most_sold_products=df['Product'].value_counts()[0:5].index
#
print(df['Product'].isin(most_sold_products))
# True menas that line most sold product is available
most_sold_products_df=df[df['Product'].isin(most_sold_products)]
print("most_sold_products_df",most_sold_products_df.head())
print(most_sold_products_df.groupby(['Month','Product']).size())
print("Pivot table",most_sold_products_df.groupby(['Month','Product']).size().unstack())
pivot=most_sold_products_df.groupby(['Month','Product']).size().unstack()
pivot.plot(figsize=(8,6))
plt.show()

x=pd.crosstab(df['Product'],df['Month'])
print(x)
x.plot(kind='bar',stacked=True)
plt.show()

# Requirement 5
# what are the most sold product together?

print(df)
print(df.columns)
print(df['Order ID'])
print(df['Order ID'].duplicated(keep=False))
filter1=df['Order ID'].duplicated(keep=False)
print("Repeated order ID",df[filter1])
df_duplicated=df[filter1]
print(df_duplicated)
print(df_duplicated.groupby(['Order ID'])['Product'].apply(lambda x : ','.join(x)))
# to conevrt function to dataframe
result=df_duplicated.groupby(['Order ID'])['Product'].apply(lambda x : ','.join(x)).reset_index()
# rename column name
print("result",result)
print("result.columns",result.columns)
df_products=result.rename(columns={'Product':'Grouped_Product'})
print(df_products)
# merge both df
# df_duplicated=df_products['Order ID']
# duplicated_products_df=df_duplicated.merge(df_products.to_frame(), left_on='Order ID', right_index=True)
print("df_duplicated",df_duplicated)
print("df_products",df_products)

duplicated_products_df=df_duplicated.merge(df_products, how='left', on='Order ID')
# duplicated_products_df=pd.merge(df_duplicated,df_products,on='Order ID',how='inner')
#drop duplicated order id

duplicated_products_df1=df_duplicated.drop_duplicates(subset=['Order ID'],keep='first',inplace=False)
# a=df_products['Grouped_Product'].value_counts()
# print(a)
print("duplicated_products_df1",duplicated_products_df1)
df_products['Grouped_Product'].value_counts().plot(kind='pie')
# a=df_products['Grouped_Product'].value_counts()
# print(a)
# df_products['Grouped_Product'].value_counts().plot(kind='pie')
plt.show()
# due merge not done no vlaues are couning for order id










